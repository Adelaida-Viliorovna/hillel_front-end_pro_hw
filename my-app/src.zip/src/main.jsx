// my-app\src\main.jsx

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import { store } from './todoStore/store';
import { swapiStore } from './swapiStore/swapiStore.js'; 

import App from './App.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Provider store={store}>
      <Provider swapiStore={swapiStore}>
      <App />
      </Provider>
    </Provider>
  </StrictMode>
);
