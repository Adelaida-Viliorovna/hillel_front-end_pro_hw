import { all, call } from 'redux-saga/effects';
import { swapiWatcher } from './swapiWatchers';

export function* rootSaga() {
    yield all([
        call(swapiWatcher),
    ]);
}