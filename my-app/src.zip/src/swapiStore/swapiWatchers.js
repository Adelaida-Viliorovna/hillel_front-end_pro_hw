import { takeLatest } from "redux-saga/effects";
import { callFetchInfoStart } from './swapiWorkers';
import { fetchInfoStart } from './swapiStore';

export function* swapiWatcher() {
    yield takeLatest(fetchInfoStart.type, callFetchInfoStart);
}
