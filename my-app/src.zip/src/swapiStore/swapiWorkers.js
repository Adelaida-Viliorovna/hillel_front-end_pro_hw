import { call, put } from 'redux-saga/effects';
import axios from 'axios';
import { setInfo, fetchInfoError } from './swapiStore';

function fetchFromApi(query) {
    return axios.get(`https://swapi.dev/api/${query}`);
}

export function* callFetchInfoStart(action) {
    try {
        const response = yield call(fetchFromApi, action.payload);
        yield put(setInfo(response.data));
    } catch (error) {
        yield put(fetchInfoError(error.message));
    }
}
