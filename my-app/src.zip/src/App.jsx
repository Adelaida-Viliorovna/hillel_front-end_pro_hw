// my-app\src\App.jsx

import TodoList from "./components/TodoList";
import Swapi from "./components/Swapi";
// import "./App.css";

const App = () => {
  return (
    <div>
      <TodoList />
      <hr />
      <Swapi />
    </div>
  );
};

export default App;