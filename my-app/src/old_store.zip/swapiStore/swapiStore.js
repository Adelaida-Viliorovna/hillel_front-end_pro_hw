import { createSlice, configureStore } from "@reduxjs/toolkit";
import createSagaMiddleware from 'redux-saga';
import { rootSaga } from './swapiRootSaga';

const sagaMiddleware = createSagaMiddleware();

const apiSlice = createSlice({
  name: "api",
  initialState: {
    result: [],
    error: null,
    loading: false,
  },
  reducers: {
    fetchInfoStart(state) {
      state.loading = true;
      state.error = null;
    },
    setInfo(state, action) {
      state.result = action.payload;
      state.loading = false;
    },
    fetchInfoError(state, action) {
      state.error = action.payload;
      state.loading = false;
    },
    clearInfo(state) {
      state.result = [];
      state.error = null;
    },
  },
});

export const { fetchInfoStart, setInfo, fetchInfoError, clearInfo } = apiSlice.actions;

export const swapiStore = configureStore({
  reducer: {
    api: apiSlice.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({ thunk: false }).concat(sagaMiddleware),
});

sagaMiddleware.run(rootSaga);
